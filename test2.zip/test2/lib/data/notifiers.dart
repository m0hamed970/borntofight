import 'package:flutter/widgets.dart';

ValueNotifier<int > selectedPageNotifier = ValueNotifier(0);
ValueNotifier<bool > isDarkModeNotifier = ValueNotifier(false);