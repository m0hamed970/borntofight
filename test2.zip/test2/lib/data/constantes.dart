import 'package:flutter/material.dart';

class Kconstant {
  static const String themeModeKey = 'themeModeKey';
}


class KTextStyle {
  static const TextStyle titleBlueText = TextStyle(
    color: Colors.blue,
    fontSize: 18.0,
    fontWeight: FontWeight.bold,
  );
  static const TextStyle descriptionText = TextStyle(
    fontSize: 16.0,
  );
  static const TextStyle formulaireText = TextStyle(
    fontSize: 16.0,
    
  );
  static const TextStyle indicationText = TextStyle(
    fontSize: 13.0,
    
  );
  static const TextStyle titretext = TextStyle(
    fontSize: 20.0,
    
  );

  static const TextStyle titreparametres = TextStyle(
    fontSize: 20.0,
    
  );


}

class KValue {
  static const String dffrancais = 'Francais';
  static const String dfanglais = 'Anglais';
  static const String dfitalien= 'Italien';
  static const String dfmaths = 'Maths';
}

class KValuemoyenne {
  static const double dffrancais = 4;
  static const double dfanglais = 5;
  static const double dfitalien= 6;
  static const double dfmaths = 3.5;
}
