import 'package:flutter/material.dart';

TextEditingController nomcontroller = TextEditingController();
TextEditingController prenomcontroller = TextEditingController();
TextEditingController courrielcontroller = TextEditingController(text: '');
TextEditingController mdpcontroller = TextEditingController();
TextEditingController confirmationcontroller = TextEditingController();
TextEditingController controllerconfirmationmail = TextEditingController();

String? classeMenuItem = '1M';

bool dffrancais = false;
bool dfallemand = false;
bool dfanglais = false;
bool dfitalien = false;
bool dfmaths = false;
bool dfbiologie = false;
bool dfchimie = false; 
bool dfphysique = false;
bool dfhistoire = false;
bool dfgeographie = false;
bool dfphilo = false;
bool dfarts = false;
bool dfmusique = false;
bool dfinformatique = false;
bool dfeco = false;

String? optionOS = 'physique_maths';
String? optionOC = '0';

double osMaths = 5.5;
double osPhysique = 4.0;
double osBio = 5.0;
double osChimie = 4.5;
double osEco = 5.0;
double osEspagnol = 4.5;
double osPhilo = 5.5;
double osPsycho = 4.0;

double ocMaths = 5.0;
double ocArts = 5.0;
double ocBio = 5.0;
double ocChimie = 5.0;
double ocEco = 5.0;
double ocGeo = 5.0;
double ocHistoire = 5.0;
double ocReligion = 5.0;
double ocInfo = 5.0;
double ocMusique = 5.0;
double ocPhysique = 5.0;
double ocSport = 5.0;

Map<String, List<double>> notesParMatiere = {};
Map<String, double> moyennesParMatiere = {};
