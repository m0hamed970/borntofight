import 'package:flutter/material.dart';
import 'package:test2/data/constantes.dart';

class ContainerWidget extends StatelessWidget {
  const ContainerWidget({super.key, required this.title, required this.description});

  final String title;
  final String description;


  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.only(top: 5.0),
      child: Card(
        child: Padding(
          padding: EdgeInsetsGeometry.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: KTextStyle.titleBlueText,
              ),
              SizedBox(
                height: 5,
              ),
              Text(
                description,
                style: KTextStyle.descriptionText,
              ),
            ],
          ),
        ),
      ),
    );
  }
}