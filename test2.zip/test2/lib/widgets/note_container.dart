import 'package:flutter/material.dart';

class NoteContainer extends StatelessWidget {
  final String matiere;
  final double moyenne;
  final List<double>? notes;
  final Function(double)? onNoteTap;

  const NoteContainer({
    Key? key,
    required this.matiere,
    required this.moyenne,
    this.notes,
    this.onNoteTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 9),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 15, 20, 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    matiere,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    child: Text(
                      moyenne.toStringAsFixed(1),
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              if (notes != null && notes!.isNotEmpty)
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: notes!
                      .map((note) => GestureDetector(
                            onTap: () => onNoteTap?.call(note),
                            child: Chip(
                              label: Text(note.toStringAsFixed(1)),
                            ),
                          ))
                      .toList(),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
