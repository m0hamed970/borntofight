import 'package:flutter/material.dart';
import 'package:test2/data/notifiers.dart';


class NavbarWidget extends StatelessWidget {
  const NavbarWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: selectedPageNotifier, 
      builder: (context, selectedPage, child) {
        return NavigationBar(
            destinations: [
              NavigationDestination(icon: Icon(Icons.home,), label: 'Accueil',),
              NavigationDestination(icon: Icon(Icons.assignment_sharp), label: 'Notes',),
              NavigationDestination(icon: Icon(Icons.settings), label: 'Paramètres',),
            ],
            onDestinationSelected: (int value) {
                selectedPageNotifier.value = value;
            },
            selectedIndex: selectedPage,
        );
      },
      );      
  }
}