import 'package:flutter/material.dart';

class HeroWidget extends StatelessWidget {
  const HeroWidget({super.key, this.nextPage,});

  final Widget? nextPage;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: GestureDetector(
        onTap: () {},
        child: Center(
          child: Hero(
            tag: 'hero1',
            child: AspectRatio(
              aspectRatio: 1920/1150,
              child: ClipRRect(
                borderRadius: BorderRadiusGeometry.circular(20.0),
                child: Image.asset(
                  fit: BoxFit.cover,
                  'assets/images/accueil.png',
                  colorBlendMode: BlendMode.modulate,
                  ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}