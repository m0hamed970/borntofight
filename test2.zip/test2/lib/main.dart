// Ajouter l'option groupe de notes, 
// Ajouter titres, coefficient, et date pour chaque note
// ajouter l'export et l'import des données
// Rendre les notes supprimables
// ajouter panier et moyenne d'OS
// atterrir directement sur la page d'accueil si identification deja faite
// voir pour déplacer le bouton '+' sur la page notes


import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:test2/data/constantes.dart';
import 'package:test2/data/notifiers.dart';
import 'package:test2/views/pages/bienvenue_page.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp
  ]);
  runApp(const MyApp());
}



class MyApp  extends StatefulWidget {
  const MyApp({super.key});


  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  @override
  void initState() {
    initThemeMode();
    super.initState();
  }

  void initThemeMode() async{
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final bool? repeat = prefs.getBool(Kconstant.themeModeKey);
    isDarkModeNotifier.value = repeat ?? false;
  }
  

  
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: isDarkModeNotifier, 
      builder: (context, isDarkMode, child) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color.fromARGB(255, 79, 117, 139), 
              brightness: isDarkMode ? Brightness.dark : Brightness.light,
            ),
          ), 
          home: WelcomePage()
        );
      }
    );
  }
}