import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DBHelper {
  static Database? _db;

  static Future<Database> initDb() async {
    if (_db != null) return _db!;

    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'notes_gymnase.db');

    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            matiere TEXT,
            valeur REAL
          )
        ''');
      },
    );
    return _db!;
  }

  static Future<List<Map<String, dynamic>>> getNotes() async {
    final db = await initDb();
    return await db.query('notes');
  }

  static Future<int> ajouterNoteAvecMatiere(String matiere, double valeur) async {
    final db = await initDb();
    return await db.insert('notes', {
      'matiere': matiere,
      'valeur': valeur,
    });
  }

  static Future<int> modifierNote(String matiere, double ancienneValeur, double nouvelleValeur) async {
    final db = await initDb();

    // On trouve la note par matière + ancienne valeur (limité mais suffit ici)
    final result = await db.query(
      'notes',
      where: 'matiere = ? AND valeur = ?',
      whereArgs: [matiere, ancienneValeur],
      limit: 1,
    );

    if (result.isNotEmpty) {
      final id = result.first['id'] as int;
      return await db.update(
        'notes',
        {'valeur': nouvelleValeur},
        where: 'id = ?',
        whereArgs: [id],
      );
    }
    return 0;
  }
}
