import 'dart:io';
import 'package:sqflite/sqflite.dart';
import 'package:permission_handler/permission_handler.dart';

import 'package:file_picker/file_picker.dart';

Future<void> exporterDB() async {
  // Demander la permission d'accéder au stockage
  final status = await Permission.storage.request();
  if (!status.isGranted) {
    throw Exception('Permission refusée');
  }

  // Chemin de la base SQLite locale
  final dbPath = await getDatabasesPath();
  final sourceFile = File('$dbPath/notes_gymnase.db');

  // Dossier de téléchargement (public sur Android)
  final downloadsDir = Directory('/storage/emulated/0/Download');
  if (!downloadsDir.existsSync()) {
    downloadsDir.createSync(recursive: true);
  }

  // Destination : copie dans le dossier Download
  final backupFile = File('${downloadsDir.path}/notes_backup.db');
  await sourceFile.copy(backupFile.path);

  print('Export terminé : ${backupFile.path}');
}


Future<void> importerDB() async {
  // Ouvrir un sélecteur de fichier
  final result = await FilePicker.platform.pickFiles(
    type: FileType.custom,
    allowedExtensions: ['db'],
  );

  // Si l'utilisateur annule
  if (result == null) return;

  // Fichier choisi
  final selectedFile = File(result.files.single.path!);

  // Chemin de la base locale
  final dbPath = await getDatabasesPath();
  final destFile = File('$dbPath/notes_gymnase.db');

  // Remplacer l’ancienne base par la nouvelle
  await selectedFile.copy(destFile.path);

  print('Import terminé depuis : ${selectedFile.path}');
}
