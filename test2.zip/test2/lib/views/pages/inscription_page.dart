import 'package:flutter/material.dart';
import 'package:test2/data/constantes.dart';
import 'package:test2/data/variables.dart';
import 'package:test2/views/widget_tree.dart';


class OnBoardingPage extends StatefulWidget {
  const OnBoardingPage({super.key});

  @override
  State<OnBoardingPage> createState() => _OnBoardingPageState();
}

class _OnBoardingPageState extends State<OnBoardingPage> {

   
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(' GyCham ', textAlign: TextAlign.center,),
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              Divider(),

              Container(
                alignment: Alignment.bottomLeft,
                padding: const EdgeInsets.all(10.0),
                child: Text(
                  'Données personelles',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
              ),

              Divider(),

              
              SizedBox(height: 20,),
        
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
        
                  TextField(
                    controller: prenomcontroller,
                    
                    decoration: InputDecoration(
                      hintText: 'Prénom',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                      )
                    ),
                    onEditingComplete:() {
                      setState(() {});
                    },
                  ),

                  SizedBox(height: 15,),

        
                  
                  FittedBox(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 0),
                      child: Row(
                        children: [
                          Text('Année', style: KTextStyle.formulaireText,),
                          SizedBox(width: 20,),
                          DropdownButton(
                              padding: EdgeInsets.symmetric(horizontal: 10),
                              alignment: Alignment.topLeft,
                              value: classeMenuItem,
                              items: [
                                DropdownMenuItem(
                                  value: '1M',
                                  child: Text('1ère de Maturité'),
                                  ),
                                DropdownMenuItem(
                                  value: '2M',
                                  child: Text('2ème de Maturité'),
                                  ),
                                DropdownMenuItem(
                                  value: '3M',
                                  child: Text('3ème de Maturité'),
                                  ),
                              ], 
                              onChanged: (String? value){
                                setState(() {
                                  classeMenuItem = value;
                                }
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
        
                  SizedBox(height: 20,),
                
                ],
              ),

              Column(
                children: [

                  Divider(),
              
                  Container(
                    alignment: Alignment.bottomLeft,
                    padding: const EdgeInsets.all(10.0),
                    child: Text(
                      'Choix des matières',
                      style: TextStyle(
                        fontSize: 20,
                      ),
                    ),
                  ),

                  Divider(),

                  SizedBox(height: 10,),
              
              
                  Column(
                    children: [
                      Text(
                        'Disciplines Fondamentales',
                        style: TextStyle(
                          fontSize: 16,                      
                        ),
                      ),
              
                      SizedBox(height: 10,),
                  
                      SwitchListTile.adaptive(
                        title: Text('Français'),
                          value: dffrancais, 
                          onChanged: (bool value){
                          setState(() {
                            dffrancais = value;
                          });
                        }
                      ),
                      SwitchListTile.adaptive(
                        title: Text('Anglais'),
                          value: dfanglais, 
                          onChanged: (bool value){
                          setState(() {
                            dfanglais = value;
                          });
                        }
                      ),
                      SwitchListTile.adaptive(
                        title: Text('Italien'),
                          value: dfitalien, 
                          onChanged: (bool value){
                          setState(() {
                            dfitalien = value;
                          });
                        }
                      ),
                      SwitchListTile.adaptive(
                        title: Text('Allemand'),
                          value: dfallemand, 
                          onChanged: (bool value){
                          setState(() {
                            dfallemand = value;
                          });
                        }
                      ),
                      SwitchListTile.adaptive(
                        title: Text('Mathématiques'),
                          value: dfmaths, 
                          onChanged: (bool value){
                          setState(() {
                            dfmaths = value;
                          });
                        }
                      ),
                      SwitchListTile.adaptive(
                        title: Text('Biologie'),
                          value: dfbiologie, 
                          onChanged: (bool value){
                          setState(() {
                            dfbiologie = value;
                          });
                        }
                      ),
                      SwitchListTile.adaptive(
                        title: Text('Chimie'),
                          value: dfchimie, 
                          onChanged: (bool value){
                          setState(() {
                            dfchimie = value;
                          });
                        }
                      ),
                      SwitchListTile.adaptive(
                        title: Text('Physique'),
                          value: dfphysique, 
                          onChanged: (bool value){
                          setState(() {
                            dfphysique = value;
                          });
                        }
                      ),
                      SwitchListTile.adaptive(
                        title: Text('Histoire'),
                          value: dfhistoire, 
                          onChanged: (bool value){
                          setState(() {
                            dfhistoire = value;
                          });
                        }
                      ),
                      SwitchListTile.adaptive(
                        title: Text('Géographie'),
                          value: dfgeographie, 
                          onChanged: (bool value){
                          setState(() {
                            dfgeographie = value;
                          });
                        }
                      ),
                      SwitchListTile.adaptive(
                        title: Text('Philosophie'),
                          value: dfphilo, 
                          onChanged: (bool value){
                          setState(() {
                            dfphilo = value;
                          });
                        }
                      ),
                      SwitchListTile.adaptive(
                        title: Text('Arts visuels'),
                          value: dfarts, 
                          onChanged: (bool value){
                          setState(() {
                            dfarts = value;
                          });
                        }
                      ),
                      SwitchListTile.adaptive(
                        title: Text('Musique'),
                          value: dfmusique, 
                          onChanged: (bool value){
                          setState(() {
                            dfmusique = value;
                          });
                        }
                      ),
                      SwitchListTile.adaptive(
                        title: Text('Informatique'),
                          value: dfinformatique, 
                          onChanged: (bool value){
                          setState(() {
                            dfinformatique = value;
                          });
                        }
                      ),
                      SwitchListTile.adaptive(
                        title: Text('Economie & droit'),
                          value: dfeco, 
                          onChanged: (bool value){
                          setState(() {
                            dfeco = value;
                          });
                        }
                      ),
                  
                  
                    ],
                  ),
              
                  SizedBox(height: 30,),
              
                  Divider(),
              
                  SizedBox(height: 10,),
              
                  FittedBox(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 0),
                      child: Column(
                        children: [
                          Text('Option Spécifique', style: KTextStyle.formulaireText,),
                          SizedBox(height: 10,),
                          DropdownButton(
                            value: optionOS,
                            items: const [
                              DropdownMenuItem(
                                value: 'physique_maths',
                                child: Text('Physique & application des maths'),
                              ),
                              DropdownMenuItem(
                                value: 'biochimie_os',
                                child: Text('Biologie & Chimie'),
                              ),
                              DropdownMenuItem(
                                value: 'eco_droit',
                                child: Text('Economie & Droit'),
                              ),
                              DropdownMenuItem(
                                value: 'espagnol',
                                child: Text('Espagnol'),
                              ),
                              DropdownMenuItem(
                                value: 'philo_psycho',
                                child: Text('Philosophie & Psychologie'),
                              ),
                            ],
                            onChanged: (String? value) {
                              setState(() {
                                optionOS = value;
                              });
                            },
                          ),

                        ],
                      ),
                    ),
                  ),
                  
                  SizedBox(height: 30,),
              
                  Divider(),
              
                  SizedBox(height: 10,),
              
                  FittedBox(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 0),
                      child: Column(
                        children: [
                          Text('Option Complémentaire', style: KTextStyle.formulaireText,),
                          SizedBox(height: 10,),
                          DropdownButton(
                              padding: EdgeInsets.symmetric(horizontal: 10),
                              alignment: Alignment.topLeft,
                              value: optionOC,
                              items: [
                                DropdownMenuItem(
                                  value: '0',
                                  child: Text('Aucune'),
                                ),
                                DropdownMenuItem(
                                  value: 'maths',
                                  child: Text('Application des Mathématiques'),
                                ),
                                DropdownMenuItem(
                                  value: 'arts',
                                  child: Text('Arts visuels'),
                                ),
                                DropdownMenuItem(
                                  value: 'bio',
                                  child: Text('Biologie'),
                                ),
                                DropdownMenuItem(
                                  value: 'chimie',
                                  child: Text('Chimie'),
                                ),
                                DropdownMenuItem(
                                  value: 'eco',
                                  child: Text('Economie & droit'),
                                ),
                                DropdownMenuItem(
                                  value: 'géo',
                                  child: Text('Géographie'),
                                ),
                                DropdownMenuItem(
                                  value: 'histoire',
                                  child: Text('Histoire'),
                                ),
                                DropdownMenuItem(
                                  value: 'religion',
                                  child: Text('Histoire des religions'),
                                ),
                                DropdownMenuItem(
                                  value: 'info',
                                  child: Text('Informatique'),
                                ),
                                DropdownMenuItem(
                                  value: 'musique',
                                  child: Text('Musique'),
                                ),
                                DropdownMenuItem(
                                  value: 'physique',
                                  child: Text('Physique'),
                                ),
                                DropdownMenuItem(
                                  value: 'sport',
                                  child: Text('Sport'),
                                ),
                              ], 
                              onChanged: (String? value){
                                setState(() {
                                  optionOC = value;
                                }
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
              
              
              
              
                
              
                  SizedBox(height: 30,),
                  FilledButton(
                    onPressed: () {
                      onNextPressed();
                    },
                    style: ElevatedButton.styleFrom(
                      minimumSize: Size(double.infinity, 40),
                    ),
                    child: Text('Finaliser'),
                    ),
                  
                  SizedBox(
                    height: 50,
                  ),
              
              
              
              
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void onNextPressed() {
    if (prenomcontroller.text.isNotEmpty){
      Navigator.pushAndRemoveUntil(
        context, 
        MaterialPageRoute(
          builder: (context){
            return WidgetTree();
          },
        ),
        (route) => false ,
      );
    }
    if (prenomcontroller.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text('Veuillez entrer votre prénom'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }
}