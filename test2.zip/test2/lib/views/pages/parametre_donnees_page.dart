import 'package:flutter/material.dart';
import 'package:test2/data/constantes.dart';
import 'package:test2/data/variables.dart';
import 'package:test2/views/widget_tree.dart';


class ParametreDonneesPage extends StatefulWidget {
  const ParametreDonneesPage({super.key});

  @override
  State<ParametreDonneesPage> createState() => _ParametreDonneesPageState();
}

class _ParametreDonneesPageState extends State<ParametreDonneesPage> {

  String messageErreurmdp= '';
  String messageErreurcourriel= '';
  String messageErreurchamps= '';





   
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('  Données personelles', textAlign: TextAlign.center,),
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: Column(
            children: [

              SizedBox(height: 20,),
              
        
        
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 7),
                    child: Container(
                      alignment: Alignment.centerLeft,
                      child: 
                        Text('Prénom', style: KTextStyle.formulaireText,),
                      ),
                  ),
        
        
                  TextField(
                    controller: prenomcontroller,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                      )
                    ),
                    onEditingComplete:() {
                      setState(() {});
                    },
                  ),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    child: Text(
                      messageErreurmdp,
                      style: TextStyle(
                        color: Colors.red,
                        fontSize: 12,
                      ),  
                    ),
                  ),
        
        
                  
                  FittedBox(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 0),
                      child: Row(
                        children: [
                          Text('Année', style: KTextStyle.formulaireText,),
                          SizedBox(width: 20,),
                          DropdownButton(
                              padding: EdgeInsets.symmetric(horizontal: 10),
                              alignment: Alignment.topLeft,
                              value: classeMenuItem,
                              items: [
                                DropdownMenuItem(
                                  value: '1M',
                                  child: Text('1ère de Maturité'),
                                  ),
                                DropdownMenuItem(
                                  value: '2M',
                                  child: Text('2ème de Maturité'),
                                  ),
                                DropdownMenuItem(
                                  value: '3M',
                                  child: Text('3ème de Maturité'),
                                  ),
                              ], 
                              onChanged: (String? value){
                                setState(() {
                                  classeMenuItem = value;
                                }
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),


                                  
                ],
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.transparent,
        elevation: 6,
        child: FilledButton(
          onPressed: () {
            
            onNextPressed();
          },
          style: ElevatedButton.styleFrom(
            minimumSize: Size(double.infinity, 40),
          ),
          child: Text('Sauvegarder'),
          ),
      ),
    );
  }

  void onNextPressed() {
    if (prenomcontroller.text.isNotEmpty){
      Navigator.pushAndRemoveUntil(
        context, 
        MaterialPageRoute(
          builder: (context){
            return WidgetTree();
          },
        ),
        (route) => false ,
      );
    }
    if (prenomcontroller.text.isEmpty) {
      setState(() {
        messageErreurmdp = 'Veuillez entrer votre prénom';
      });
    }
  }
}
