import 'package:flutter/material.dart';
import 'package:test2/database/db_helper.dart';
import 'package:test2/database/export_import.dart';
import 'package:test2/views/pages/inscription_page.dart';
import 'package:test2/views/pages/parametre_donnees_page.dart';

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/images/Logo.png', width: 200,),
              FittedBox(
                child: Text(
                  'GyCham',
                  style: TextStyle(
                    fontSize: 30.0,
                    color: Colors.blueGrey,
                    letterSpacing: 5,
                  ),
                  ),
              ),
              SizedBox(
                height: 50,
              ),
              Container(
                width: 300,
                child: FilledButton(
                  onPressed: () {
                    Navigator.push(
                      context, 
                      MaterialPageRoute(
                        builder: (context){
                          return OnBoardingPage();
                        },
                      ),
                    );
                  }, 
                  style: FilledButton.styleFrom(
                    minimumSize: Size(double.infinity, 40),
                  ),
                  child: Text('Commencer')
                  ),
              ),
              TextButton(
                onPressed: () async {
                  try {
                    await importerDB();
                    // Après import, on récupère les notes depuis la DB
                    final notes = await DBHelper.getNotes();

                    // Naviguer vers LoginPage en passant les notes en argument
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) {
                          return ParametreDonneesPage();
                        },
                      ),
                    );
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Erreur lors de l’import : $e')),
                    );
                  }
                },
                style: FilledButton.styleFrom(
                  minimumSize: Size(double.infinity, 40),
                ),
                child: Text(
                  'Importer des données',
                  style: TextStyle(fontSize: 12),
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}