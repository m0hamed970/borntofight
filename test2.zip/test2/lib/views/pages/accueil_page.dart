import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:test2/data/constantes.dart';
import 'package:test2/data/variables.dart';
import 'package:test2/widgets/hero_widget.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  void _openLink(BuildContext context, String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Impossible d\'ouvrir le lien : $url')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        title: const Text('Gy Cham'),
        actions: [
          IconButton(
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Contact support'),
                  content: const Text(
                    "Pour toute question relative à vos données personnelles ou à l'utilisation de l'application, veuillez vous adresser au service informatique au 2ème étage du batiment A.",
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Fermer'),
                    ),
                  ],
                ),
              );
            },
            icon: const Icon(Icons.contact_support),
          ),
        ],
      ),



      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              
              const HeroWidget(),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: Text('Bienvenue ${prenomcontroller.text}', style: KTextStyle.titretext),
              ),
              const SizedBox(height: 20),

              ListTile(
                leading: const Icon(Icons.school),
                title: const Text('Hermes Eduvaud'),
                onTap: () => _openLink(context, 'https://hermes.edu-vaud.ch'),
              ),
              ListTile(
                leading: const Icon(Icons.email),
                title: const Text('Outlook'),
                onTap: () => _openLink(context, 'https://outlook.office.com'),
              ),
              ListTile(
                leading: const Icon(Icons.apps),
                title: const Text('Office.com'),
                onTap: () => _openLink(context, 'https://www.office.com'),
              ),
              ListTile(
                leading: const Icon(Icons.language),
                title: const Text('Site du Gymnase de Chamblandes'),
                onTap: () => _openLink(context, 'https://www.chamblandes.ch'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
