import 'package:flutter/material.dart';
import 'package:test2/views/widget_tree.dart';
import 'package:test2/data/variables.dart';


class LoginPage extends StatefulWidget {
  const LoginPage({super.key, required this.title,});

  final String title;

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  
  TextEditingController controllerEmail = TextEditingController();
  TextEditingController controllerPw = TextEditingController();

  String messageErreur = '';

  @override
  void dispose() {
    controllerEmail.dispose();
    controllerPw.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Se connecter'),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                Image.asset('assets/images/Logo.png', width: 200,),
                SizedBox(
                  height: 30,
                ),
                TextField(
                  controller: controllerEmail,
                  autocorrect: false,
                  decoration: InputDecoration(
                    hintText: 'Email',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),
                    ), 
                    ),
                  onEditingComplete:() {
                    setState(() {});
                  },
                ),
          
                SizedBox(
                  height: 15,
                ),
          
                TextField(
                  controller: controllerPw,
                  decoration: InputDecoration(
                    hintText: 'Password',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),
                    ), 
                    ),
                  obscureText: true,
                  onEditingComplete:() {
                    setState(() {});
                  },
                ),
          
                SizedBox(
                  height: 10,
                ),
          
                Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Text(
                    messageErreur,
                    style: TextStyle(
                      color: Colors.red,
                      fontSize: 12,
                    ),  
                  ),
                ),
          
                FilledButton(
                  onPressed: () {
                    onLoginPressed();
                  },
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(double.infinity, 40),
                  ),
                  child: Text(widget.title),
                  ),
                
                SizedBox(
                  height: 150,
                )
                
                
              ],
            ),
          ),
        ),
      ),
    );
  }




  void onLoginPressed() {
    if (controllerEmail.text == courrielcontroller.text && courrielcontroller.text != '' && mdpcontroller.text == controllerPw.text && mdpcontroller.text != ''){
      Navigator.pushAndRemoveUntil(
        context, 
        MaterialPageRoute(
          builder: (context){
            return WidgetTree();
          },
        ),
        (route) => false ,
      );
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Connexion réussite'),
          duration: Duration(seconds: 2),
          behavior: SnackBarBehavior.floating,

        ),
      );
    }
    else if (controllerEmail.text != courrielcontroller.text && mdpcontroller.text != controllerPw.text) {
    setState(() {
      messageErreur = 'Email ou mot de passe incorrect';
    });
    }
    else if (courrielcontroller.text.isEmpty && mdpcontroller.text.isEmpty) {
    setState(() {
      messageErreur = 'Veuillez saisir un email et un mot de passe valides';
    });
    }
}
}