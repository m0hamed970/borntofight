import 'package:flutter/material.dart';
import 'package:test2/database/db_helper.dart';
import 'package:test2/widgets/note_container.dart';  // Assure-toi que c’est bien importé

class MarkPage extends StatefulWidget {
  const MarkPage({Key? key}) : super(key: key);

  @override
  State<MarkPage> createState() => _MarkPageState();
}

class _MarkPageState extends State<MarkPage> {
  String? matiereChoisie;
  final TextEditingController champNote = TextEditingController();

  // Map pour stocker localement les notes chargées
  Map<String, List<double>> notesParMatiere = {};
  Map<String, double> moyennesParMatiere = {};

  @override
  void initState() {
    super.initState();
    _chargerNotesDepuisDb();
  }

  Future<void> _chargerNotesDepuisDb() async {
    // Récupérer toutes les notes depuis la base SQLite
    final listeNotes = await DBHelper.getNotes();

    Map<String, List<double>> notesMap = {};

    // Transformer la liste en Map <matiere, List<note>>
    for (var note in listeNotes) {
      final matiere = note['matiere'] as String? ?? 'Inconnue';
      final valeur = double.tryParse(note['valeur'].toString()) ?? 0.0;

      if (!notesMap.containsKey(matiere)) {
        notesMap[matiere] = [];
      }
      notesMap[matiere]!.add(valeur);
    }

    setState(() {
      notesParMatiere = notesMap;
      recalculerMoyennes();
    });
  }

  @override
  Widget build(BuildContext context) {
    final listeMatieres = notesParMatiere.keys.toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notes'),
        actions: [
          IconButton(
            icon: const Icon(Icons.contact_support),
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Aide'),
                  content: SizedBox(
                    height: 150,
                    child: Column(
                      children: const [
                        Text(
                          "Pour modifier une note ou un groupe de note après l'avoir ajouté, cliquez sur la note ou le groupe de note en question",
                        ),
                        SizedBox(height: 10),
                        Text(
                          "Pour ajouter ou supprimer une matière, il faut aller dans les paramètres de l'application.",
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: ListView(
          children: listeMatieres.map((matiere) {
            return NoteContainer(
              matiere: matiere,
              moyenne: moyennesParMatiere[matiere] ?? 0.0,
              notes: notesParMatiere[matiere],
              onNoteTap: (note) {
                afficherDialogueModificationNote(matiere, note);
              },
            );
          }).toList(),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: afficherDialogueAjoutNote,
        child: const Icon(Icons.add),
      ),
    );
  }

  void afficherDialogueAjoutNote() {
    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            return AlertDialog(
              title: const Text("Ajouter une note"),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  DropdownButton<String>(
                    isExpanded: true,
                    value: matiereChoisie,
                    hint: const Text("Choisir une matière"),
                    items: notesParMatiere.keys.map((x) {
                      return DropdownMenuItem(
                        value: x,
                        child: Text(x),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setStateDialog(() {
                        matiereChoisie = value;
                      });
                    },
                  ),
                  TextField(
                    controller: champNote,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(hintText: "Note"),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Annuler"),
                ),
                TextButton(
                  onPressed: () async {
                    if (matiereChoisie != null && champNote.text.trim().isNotEmpty) {
                      String texte = champNote.text.trim().replaceAll(',', '.');
                      double? note = double.tryParse(texte);

                      if (note != null && note >= 1 && note <= 6) {
                        // Sauvegarde en base locale
                        await DBHelper.ajouterNoteAvecMatiere(matiereChoisie!, note);

                        // Recharger les notes
                        await _chargerNotesDepuisDb();

                        champNote.clear();
                        matiereChoisie = null;
                        Navigator.pop(context);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("Note invalide (entre 1 et 6)")),
                        );
                      }
                    }
                  },
                  child: const Text("Ajouter"),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void afficherDialogueModificationNote(String matiere, double ancienneNote) {
    final TextEditingController modifNoteController =
        TextEditingController(text: ancienneNote.toString());

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Modifier la note"),
          content: TextField(
            controller: modifNoteController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(hintText: "Nouvelle note"),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Annuler"),
            ),
            TextButton(
              onPressed: () async {
                String texte = modifNoteController.text.trim().replaceAll(',', '.');
                double? nouvelleNote = double.tryParse(texte);

                if (nouvelleNote != null && nouvelleNote >= 1 && nouvelleNote <= 6) {
                  // Modifier la note en base SQLite
                  await DBHelper.modifierNote(matiere, ancienneNote, nouvelleNote);

                  await _chargerNotesDepuisDb();

                  Navigator.pop(context);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Note invalide (entre 1 et 6)")),
                  );
                }
              },
              child: const Text("Enregistrer"),
            ),
          ],
        );
      },
    );
  }

  void recalculerMoyennes() {
    moyennesParMatiere.clear();
    notesParMatiere.forEach((nomMatiere, listeNotes) {
      if (listeNotes.isNotEmpty) {
        double somme = listeNotes.reduce((a, b) => a + b);
        double moyenne = somme / listeNotes.length;
        double moyenneArrondie = (moyenne * 2).round() / 2;
        moyennesParMatiere[nomMatiere] = moyenneArrondie;
      } else {
        moyennesParMatiere[nomMatiere] = 0.0;
      }
    });
  }
}
