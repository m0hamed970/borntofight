import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:test2/data/constantes.dart';
import 'package:test2/data/notifiers.dart';
import 'package:test2/database/export_import.dart';
import 'package:test2/views/pages/parametre_donnees_page.dart';
import 'package:test2/views/pages/parametres_matieres_page.dart';
import 'package:test2/views/pages/bienvenue_page.dart';
import 'package:test2/data/variables.dart';

class ProfilePage  extends StatefulWidget {
  const ProfilePage ({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {

  TextEditingController controllermdpparametres = TextEditingController();

  String messageErreurparametresmdp = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        
        title: Text(' Paramètres'),
        leading: IconButton(
          onPressed: () async{
            isDarkModeNotifier.value = !isDarkModeNotifier.value;
            final SharedPreferences prefs = await SharedPreferences.getInstance();
            await prefs.setBool(Kconstant.themeModeKey, isDarkModeNotifier.value);
          },
          icon: ValueListenableBuilder(
            valueListenable: isDarkModeNotifier,
            builder: (context, isDarkMode, child) {
              return Icon(
                isDarkMode ? Icons.light_mode : Icons.dark_mode,
              );
            },
          ),
        ),
        
        actions: [
          IconButton(
            onPressed: () {
              showDialog(
                context: context, 
                builder: (context) {
                  return AlertDialog(
                    title: Text('Se déconnecter'),
                    content: Text('Voulez-vous vraiment vous déconnectez ?',),
                    
                    actions: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            }, 
                            child: Text('Annuler')
                          ),

                          SizedBox(width: 30,),

                          FilledButton(
                            onPressed: () {
                              selectedPageNotifier.value = 0;
                                Navigator.pushAndRemoveUntil(
                                  context, 
                                  MaterialPageRoute(
                                    builder: (context){
                                      return WelcomePage();
                                    },
                                  ),
                                  (route) => false ,
                                );
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('Déconnexion réussite'),
                                    duration: Duration(seconds: 2),
                                    behavior: SnackBarBehavior.floating,

                                  ),
                                );
                              }, 
                            child: Text('Oui')
                          ),
                        ],
                      ),
                      
                    ],
                    
                  );
                }
              );
            }, 
            icon: Icon(Icons.logout)
          )
        ],
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Container(
            width: double.infinity,
            child: Column(
              children: [
                Divider(),
                  FittedBox(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(width: 30,),
                        Image.asset('assets/images/Logo.png', width: 130,),
                        
                        SizedBox(width: 60,),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(prenomcontroller.text, style: TextStyle(fontSize: 18),),
                            Text(classeMenuItem!, style: TextStyle(fontSize: 18),),
                          ],
                        ),
                        SizedBox(width: 50,),
                      ],
                    ),
                  ),
                Divider(),
                SizedBox(height: 20,),
        
                
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  width: double.infinity,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      
                      Text('Profil', style: KTextStyle.titreparametres),
        
                      SizedBox(height: 10,),
                      
                      TextButton(
                        onPressed: () {
                          Navigator.pushAndRemoveUntil(
                            context, 
                            MaterialPageRoute(
                              builder: (context){
                                return ParametreDonneesPage();
                              },
                            ),
                            (route) => false ,
                          );
                        },
                        child: Text('Modifier ses informations',),
                        
                      ),







                      
                      SizedBox(height: 15,),
                                
                      Text('Matières', style: KTextStyle.titreparametres,),
                      
                      SizedBox(height: 10,),
                      
                      TextButton(
                        onPressed: () {
                          Navigator.push(
                          context, 
                          MaterialPageRoute(
                            builder: (context){
                              return ParametresMatieresPage();
                            },
                          ),
                        );
        
                        }, 
                        child: Text('Modifier les matières'),
                      ),
        
                      SizedBox(height: 15,),

                      Text('Données', style: KTextStyle.titreparametres,),
                      
                      SizedBox(height: 10,),
                      
                      TextButton(
                        onPressed: () async {
                          try {
                            await exporterDB();
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Export terminé ! Fichier dans le dossier Download.')),
                            );
                          } catch (e) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Erreur lors de l’export : $e')),
                            );
                          }
                        },
                        child: Text('Exporter les données'),
                      ),

                      

                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}